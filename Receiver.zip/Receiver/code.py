import board
import busio
import time
import digitalio
import terminalio
import neopixel
import adafruit_rfm9x
from adafruit_display_text import label
import adafruit_displayio_ssd1306
import displayio



time.sleep(1)  # Sleep for a bit to avoid a race condition on some systems

# Set up I2C and OLED display
displayio.release_displays()
i2c = busio.I2C(scl=board.SCL, sda=board.SDA)
display_bus = displayio.I2CDisplay(i2c, device_address=0x3C)
WIDTH = 128
HEIGHT = 64
display = adafruit_displayio_ssd1306.SSD1306(display_bus, width=WIDTH, height=HEIGHT, rotation=180)

def display_text(text):
    """Helper function to display text on the OLED using displayio."""
    splash = displayio.Group()
    text_area = label.Label(terminalio.FONT, text=text, color=0xFFFFFF, x=2, y=30)
    splash.append(text_area)
    display.root_group = splash



# Neopixel setup
pixel = neopixel.NeoPixel(board.IO10, 2, brightness=0.2)
pixel.fill((255, 0, 0))  # Set initial color to RED

# LoRa radio setup
RADIO_FREQ_MHZ = 915.0  
CS = digitalio.DigitalInOut(board.IO9)
RESET = digitalio.DigitalInOut(board.IO4)
spi = busio.SPI(board.IO6, MOSI=board.IO8, MISO=board.IO7)
rfm9x = adafruit_rfm9x.RFM9x(spi, CS, RESET, RADIO_FREQ_MHZ)
rfm9x.tx_power = 23  # Set transmission power



flash = digitalio.DigitalInOut(board.IO14)
flash.direction = digitalio.Direction.OUTPUT


while True:
    packet = rfm9x.receive()
    # Optionally change the receive timeout from its default of 0.5 seconds:
    # packet = rfm9x.receive(timeout=5.0)
    # If no packet was received during the timeout then None is returned.
    if packet is None:
        # Packet has not been received
        pixel.fill((255, 0, 0))
        print("Received nothing! Listening again...")
        display_text("Listening for packets")
    else:
        # Received a packet!
        pixel.fill((0, 255, 0))  # equivalent

        packet_text = str(packet, "ascii")

        rssi = rfm9x.last_rssi
        
        display_text("Packet received:{0}dB".format(rssi))
        if "flash" in packet_text:
            flash.value = True
            time.sleep(1)
            flash.value = False
        else:
            flash.value = False
