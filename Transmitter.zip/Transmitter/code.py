import board
import busio
import time
import digitalio
import terminalio
import neopixel
import adafruit_rfm9x
from adafruit_display_text import label
import adafruit_displayio_ssd1306
import displayio

# Set up I2C and OLED display
displayio.release_displays()
i2c = busio.I2C(scl=board.SCL, sda=board.SDA)
display_bus = displayio.I2CDisplay(i2c, device_address=0x3C)
WIDTH = 128
HEIGHT = 64
display = adafruit_displayio_ssd1306.SSD1306(display_bus, width=WIDTH, height=HEIGHT, rotation=180)

def display_text(text):
    """Helper function to display text on the OLED."""
    splash = displayio.Group()
    text_area = label.Label(terminalio.FONT, text=text, color=0xFFFFFF, x=10, y=30)
    splash.append(text_area)
    display.root_group = splash

# Display initial message
display_text("Hold button to send")

# Neopixel setup
pixel = neopixel.NeoPixel(board.IO10, 2, brightness=0.2)
pixel.fill((255, 0, 0))  # Set initial color to RED

# LoRa radio setup
RADIO_FREQ_MHZ = 915.0  
CS = digitalio.DigitalInOut(board.IO9)
RESET = digitalio.DigitalInOut(board.IO4)
spi = busio.SPI(board.IO6, MOSI=board.IO8, MISO=board.IO7)
rfm9x = adafruit_rfm9x.RFM9x(spi, CS, RESET, RADIO_FREQ_MHZ)
rfm9x.tx_power = 23  # Set transmission power

# Button setup
button = digitalio.DigitalInOut(board.IO44)
button.switch_to_input(pull=digitalio.Pull.UP)

# Debouncing
DEBOUNCE_DELAY = 0.05  
button_pressed = False  

# Timers for non-blocking delays
message_display_time = 0
pixel_reset_time = 0  # Timer to reset NeoPixels

while True:
    current_time = time.monotonic() 

    # Read button state
    current_button_state = button.value

    # Debouncing Logic
    if not current_button_state:  
        if not button_pressed:  
            time.sleep(DEBOUNCE_DELAY) 
            if not button.value:  
                button_pressed = True  
                rfm9x.send(bytes("flash", "utf-8"))
                print("Packet Sent!")
                display_text("Packet Sent!")
                pixel.fill((0, 255, 0))
                pixel_reset_time = current_time + 1
                message_display_time = current_time + 1

    elif button_pressed:  
        time.sleep(DEBOUNCE_DELAY)  
        if button.value:
            button_pressed = False  

    # Reset OLED after 1 second
    if message_display_time and current_time > message_display_time:
        display_text("Hold button to send")
        message_display_time = 0  

    # Reset NeoPixels after 1 second
    if pixel_reset_time and current_time > pixel_reset_time:
        pixel.fill((255, 0, 0))  
        pixel_reset_time = 0  

    # Check for incoming LoRa packets
    packet = rfm9x.receive()
    if packet:
        pixel.fill((0, 255, 0))  # Turn GREEN when a packet is received
        packet_text = str(packet, "ascii")
        print(f"Received: {packet_text}")
        display_text(f"Received: {packet_text}")
        message_display_time = current_time + 1  # Display message for 1 second